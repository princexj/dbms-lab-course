-- Rudra patel 240123076 - replica
-- Prince Jangra 240123050 - source

--- TASK 01---

CREATE DATABASE week13a;
CREATE DATABASE week13b;

--- TASK 03---
STOP REPLICA;
RESET REPLICA ALL;
CHANGE REPLICATION SOURCE TO 
  SOURCE_HOST='172.16.114.232', 
  SOURCE_USER='replica_user', 
  SOURCE_PASSWORD='Yash@2026', 
  SOURCE_LOG_FILE='mysql-bin.000004', 
  SOURCE_LOG_POS=157;
START REPLICA;
SHOW REPLICA STATUS\G

-- Task 04b
USE week13a;
SHOW TABLES;
DESCRIBE sailor;
DESCRIBE boat;
DESCRIBE reserve;

-- Task 05b
SELECT * FROM sailor;
SELECT * FROM boat;
SELECT * FROM reserve;

-- Task 06b
SELECT * FROM sailor WHERE sid = 999;
SELECT * FROM boat WHERE bid = 999;
SELECT * FROM reserve WHERE sid = 999;

-- Task 07b
DESCRIBE sailor;
DESCRIBE boat;
DESCRIBE reserve;

-- Task 08b
SHOW REPLICA STATUS\G


--- TASK 09b
SELECT * FROM reserve WHERE bid = 1001;

-- Task 10b
SELECT * FROM sailor_resere_boat;

-- Task 11b
USE week13b;
show tables;
SELECT * FROM reserve_details; 
SELECT * FROM reserve_details; 
SELECT * FROM reserve_details; 
SELECT * FROM reserve_details; 
SELECT * FROM reserve_details; 

--- TASKS 12
STOP REPLICA;
Quit;

-- Task 13
#sudo service mysql stop
