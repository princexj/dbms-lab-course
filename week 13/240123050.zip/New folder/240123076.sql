-- Rudra Patel 240123076: source
-- Prince Jangra 240123050 : replica


-- TASK 01
CREATE DATABASE week13a;
CREATE DATABASE week13b;
-- TASK 02

SHOW VARIABLES LIKE 'log_bin';
CREATE USER 'replica'@'%' IDENTIFIED WITH mysql_native_password BY 'Yash@2026';
GRANT REPLICATION SLAVE ON *.* TO 'replica_user'@'%';
FLUSH PRIVILEGES;
SHOW MASTER STATUS;

-- TASK 04
USE week13a;

CREATE TABLE sailor (
    sid INT PRIMARY KEY,
    sname CHAR(50),
    rating INT,
    age DECIMAL(3,1)
);

CREATE TABLE boat (
    bid INT PRIMARY KEY,
    bname CHAR(50),
    bcolor CHAR(50)
);

CREATE TABLE reserve (
    sid INT,
    bid INT,
    day DATE,
    PRIMARY KEY (sid, bid, day),
    FOREIGN KEY (sid) REFERENCES sailor(sid) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (bid) REFERENCES boat(bid) ON UPDATE CASCADE ON DELETE CASCADE
);

-- TASK 05
LOAD DATA LOCAL INFILE 'sailors.csv' INTO TABLE sailor   FIELDS TERMINATED BY ','   LINES TERMINATED BY '\n';
LOAD DATA LOCAL INFILE 'boats.csv' INTO TABLE boat  FIELDS TERMINATED BY ','   LINES TERMINATED BY '\n';
LOAD DATA LOCAL INFILE 'reserves.csv' INTO TABLE reserve   FIELDS TERMINATED BY ','   LINES TERMINATED BY '\n';


-- TASK 06
ALTER TABLE sailor ADD COLUMN earning INT DEFAULT 100;
ALTER TABLE boat ADD COLUMN make CHAR(20) DEFAULT 'Toyota';
ALTER TABLE reserve ADD COLUMN amount INT DEFAULT 10;

INSERT INTO sailor (sid, sname, rating, age, earning) VALUES (999, 'Captain Jack', 10, 45.5, 500);
INSERT INTO boat (bid, bname, bcolor, make) VALUES (999, 'Black Pearl', 'Black', 'Yamaha');
INSERT INTO reserve (sid, bid, day, amount) VALUES (999, 999, '2026-04-20', 50);


-- TASK 07
ALTER TABLE sailor DROP COLUMN earning;
ALTER TABLE boat DROP COLUMN make;
ALTER TABLE reserve DROP COLUMN amount;

-- TASK 08
DELIMITER //
CREATE PROCEDURE insert_sailors()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE max_id INT;
    SELECT COALESCE(MAX(sid), 0) INTO max_id FROM sailor;
    
    WHILE i <= 10000 DO
        INSERT INTO sailor (sid, sname, rating, age) 
        VALUES (max_id + i, CONCAT('Sailor_', i), 5, 25.0);
        SET i = i + 1;
    END WHILE;
END //
DELIMITER ;

CALL insert_sailors();

-- TASK 09
DELIMITER //
CREATE TRIGGER after_boat_insert 
AFTER INSERT ON boat 
FOR EACH ROW 
BEGIN
    DECLARE random_sid INT;
    SELECT sid INTO random_sid FROM sailor ORDER BY RAND() LIMIT 1;
    
    INSERT INTO reserve (sid, bid, day) 
    VALUES (random_sid, NEW.bid, CURDATE() - INTERVAL FLOOR(RAND() * 30) DAY);
END //
DELIMITER ;

INSERT INTO boat (bid, bname, bcolor) VALUES (1001, 'Trigger Boat', 'Red');
SELECT * FROM reserve WHERE bid = 1001;

-- TASK 10
CREATE or replace sql security invoker VIEW sailor_resere_boat AS 
SELECT s.sname, b.bname, r.day 
FROM sailor s 
JOIN reserve r ON s.sid = r.sid 
JOIN boat b ON r.bid = b.bid;


-- TASK 11
USE week13b;

CREATE TABLE sailor (
    sid INT PRIMARY KEY,
    sname CHAR(50),
    rating INT,
    age DECIMAL(3,1)
);

CREATE TABLE boat (
    bid INT PRIMARY KEY,
    bname CHAR(50),
    bcolor CHAR(50)
);

CREATE TABLE reserve (
    sid INT,
    bid INT,
    day DATE,
    PRIMARY KEY (sid, bid, day),
    FOREIGN KEY (sid) REFERENCES sailor(sid) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (bid) REFERENCES boat(bid) ON UPDATE CASCADE ON DELETE CASCADE
);

LOAD DATA LOCAL INFILE 'sailors.csv' INTO TABLE sailor   FIELDS TERMINATED BY ','   LINES TERMINATED BY '\n';
LOAD DATA LOCAL INFILE 'boats.csv' INTO TABLE boat  FIELDS TERMINATED BY ','   LINES TERMINATED BY '\n';
LOAD DATA LOCAL INFILE 'reserves.csv' INTO TABLE reserve   FIELDS TERMINATED BY ','   LINES TERMINATED BY '\n';

CREATE TABLE reserve_details (
    sname CHAR(50),
    bname CHAR(50),
    day DATE,
    PRIMARY KEY (sname, bname, day)
);

UPDATE sailor SET rating = 10 WHERE sid = 29;
DELETE FROM sailor WHERE sid = 74;
UPDATE boat SET bcolor = 'red' WHERE bid = 101;
DELETE FROM boat WHERE bid = 102;

exit;
sudo service mysql stop
