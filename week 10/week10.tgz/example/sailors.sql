drop function if exists rating_above;

DELIMITER $$

CREATE FUNCTION rating_above(given_rating int)
RETURNS INT
DETERMINISTIC
BEGIN
	DECLARE local_sid INT DEFAULT 0;
	DECLARE local_sname CHAR(10) DEFAULT 'new_sailor';
	DECLARE local_rating INT DEFAULT 0;
	DECLARE local_age INT DEFAULT 0;
	DECLARE local_count INT DEFAULT 0;
  DECLARE NO_record INT DEFAULT 0;

  DECLARE traverse_sailor CURSOR FOR SELECT * FROM sailors;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET NO_record = 1;

  OPEN traverse_sailor;

	L1_loop: LOOP
		FETCH traverse_sailor INTO local_sid, local_sname, local_rating, local_age;	

		IF NO_record = 1
		THEN
			LEAVE L1_loop;
		END IF;

		IF local_rating >= given_rating
		THEN
			SET local_count = local_count + 1;
		END IF;
  END LOOP;

	CLOSE traverse_sailor;

	RETURN local_count;

END $$

DELIMITER ;
