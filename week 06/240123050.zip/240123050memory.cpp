#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

int main() {
    std::ifstream inputFile("ATMs.csv");
    std::ofstream outputFile("load_atms.sql");

    if (!inputFile.is_open()) {
        std::cerr << "Error: Create a file named ATMs.csv first!" << std::endl;
        return 1;
    }

    std::string line;
    while (std::getline(inputFile, line)) {
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string bank, lat, lng, atm_no;

        if (std::getline(ss, bank, ',') && std::getline(ss, lat, ',') && 
            std::getline(ss, lng, ',') && std::getline(ss, atm_no, ',')) {
            
          
            outputFile << "INSERT INTO ATMs_memory (bank, lat, lon, atm_no) VALUES ('" 
                       << bank << "', " << lat << ", " << lng << ", '" << atm_no << "');\n";
        }
    }
    outputFile.close();
    inputFile.close();
    return 0;
}
