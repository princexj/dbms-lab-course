drop database week06;
-- task01
create database week06;
-- task02
use week06;

-- task03
create table T1_default(
name char(20),
roll_number int,
CPI float);

INSERT INTO T1_default (name, roll_number, CPI) VALUES 
('student_01', 270101999, 9.8),
('student_02', 270101998, 8.9),
('student_03', 270101997, 7.6);

update T1_default set CPI= 8.1 where name = 'student_03';
update T1_default set name='student_03a' where name='student_03';
delete from T1_default where name='student_03a';
INSERT INTO T1_default (name, roll_number, cpi) VALUES ('student 03', 270101997, 8.1);

-- task 04
create table T2_default(
name char(20),
roll_number int ,
CPI float,
primary key(roll_number));

INSERT INTO T2_default (name, roll_number, CPI) VALUES 
('student_01', 270101999, 9.8),
('student_02', 270101998, 8.9),
('student_03', 270101997, 7.6);

update T2_default set roll_number=270101998 where name = 'student_01';
update T2_default set roll_number=null where name = 'student_01';
INSERT INTO T2_default (name, roll_number, cpi) VALUES ('student_04', 270101997, 7.1);
INSERT INTO T2_default (name,roll_number,cpi) values(NULL, 270101996, 7.6);

-- task 05
create table T3_default(
name char(20) not null,
roll_number int unique not null,
CPI float);

INSERT INTO T3_default (name, roll_number, cpi) VALUES 
('student_01', 270101999, 9.8),
('student_02', 270101998, 8.9),
('student_03', 270101997, 7.6);

update T3_default set roll_number=270101998 where name='student_01';
update T3_default set roll_number=null where name='student_01';
INSERT INTO T3_default (name,roll_number,cpi) values('student_04', 270101997, 7.1);
INSERT INTO T3_default (name,roll_number,cpi) values(NULL, 270101996, 7.1);

-- task06
create table T4_default like T1_default;
INSERT INTO T4_default (name, roll_number, cpi) VALUES 
('student_01', 270101999, 9.8),
('student_02', 270101998, 8.9),
('student_03', 270101998, 8.6),
('student_04', 270101998, 8.5),
(NULL, 270101997, 7.6);

Alter table T4_default add constraint  primary key(roll_number);
ALTER TABLE T4_default MODIFY name char(20) NOT NULL;
UPDATE T4_default SET roll_number = 270101998 WHERE name = 'student_01';
UPDATE T4_default SET name=NULL where name='student03';


-- task 07
CREATE TABLE ATMs_csv (
    bank CHAR(10) not null,
    lat FLOAT not null,
    lon FLOAT not null,
    atm_no CHAR(20) not null
) ENGINE=CSV;


DELETE FROM ATMs_csv WHERE bank = 'PNB';
UPDATE ATMs_csv SET lat = 17.677010 WHERE bank = 'SBI' AND lat = 17.687194;
SELECT * FROM ATMs_csv;
ALTER TABLE ATMs_csv ADD constraint PRIMARY KEY (lat, lon);

-- task 08
CREATE TABLE ATMs_memory (
    bank CHAR(10),
    lat FLOAT,
    lon FLOAT,
    atm_no CHAR(20)
) ENGINE=MEMORY;
ALTER TABLE ATMs_memory ADD constraint PRIMARY KEY (lat, lon);
DELETE FROM ATMs_memory WHERE bank = 'PNB';
UPDATE ATMs_memory SET lat = 17.677010 WHERE bank = 'SBI' AND lat = 17.687194;
SELECT * FROM ATMs_memory;




